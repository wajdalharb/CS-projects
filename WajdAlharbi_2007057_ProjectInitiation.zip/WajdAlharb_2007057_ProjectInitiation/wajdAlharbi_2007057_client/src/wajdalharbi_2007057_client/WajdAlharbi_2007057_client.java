/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wajdalharbi_2007057_client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author wajda
 */
public class WajdAlharbi_2007057_client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
       // TODO code application logic here
        DataInputStream dataInputStream;
        DataOutputStream dataOutputStream;
        
        //create client socket with a port number 1223, and local ip 
        Socket clientSocket = new Socket("localhost",1223);
        
        //datastream to help the client read data 
        dataInputStream = new DataInputStream(clientSocket.getInputStream());
        //datastream to help the client send data to server
        dataOutputStream = new DataOutputStream(clientSocket.getOutputStream());
        
        //get user input
        Scanner sc = new Scanner(System.in);
        
        //program header
        System.out.println("---------------\n"
                + "Welcome! if you want to terminate the program please enter the word \"End\"\n"
                + "---------------");
        
        //starting the connection 
        while(true){
        
        //get user input    
        System.out.print("Enter the MAC Address you want to check: ");
        String MACaddress = sc.next();
        
       
        dataOutputStream.writeUTF(MACaddress);
        
        // if client entered "end", close the connection
        if(MACaddress.equalsIgnoreCase("end")){
            break;
        }
        
        
       //get validity from the server
        String validity = dataInputStream.readUTF();
        
        // print the validity of the address
        System.out.println(validity+"\n");
        
        } 
       
        System.out.println("\nThank you. ");
        //clolse socket
        clientSocket.close();
    }
    
}
