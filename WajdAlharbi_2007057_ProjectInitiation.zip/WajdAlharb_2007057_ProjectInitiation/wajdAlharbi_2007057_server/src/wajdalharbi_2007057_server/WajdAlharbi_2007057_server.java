/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wajdalharbi_2007057_server;
import java.io.*;
import java.io.IOException;
import java.net.Socket;
import java.net.ServerSocket;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 *
 * @author wajda
 */
public class WajdAlharbi_2007057_server {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
     // TODO code application logic here
        DataInputStream dataInputStream;
        DataOutputStream dataOutputStream;
        
        
        //create a server socket for the server with the same port number 1223
        ServerSocket serverSocket = new ServerSocket(1223);
        
        //create socket
        Socket socket;
    
        //connection TCP
        while (true) {

            //accept socket
            socket = serverSocket.accept(); 

            //display the success of the connection
            System.out.println("Client is connected.");

            //datastreams to help the server read data 
            dataInputStream = new DataInputStream(socket.getInputStream());
            dataOutputStream = new DataOutputStream(socket.getOutputStream());

            while (true) {
                //read data from the client side
                String MACaddress = dataInputStream.readUTF();
                
                // if client entered "end", close the connection
                if (MACaddress.equalsIgnoreCase("end")) {
                    break; 
                }
                //display the input that the client entered on the server 
                System.out.println("The client has sent the address: " + MACaddress);

                //send the MAC Address to the method that checks its validity
                String answer = isValidMACAddress(MACaddress);

                //inform the client of the validity of the MAC Address
                dataOutputStream.writeUTF(answer);

            }

            //close the connection
            socket.close();
        }

    }

    //////////////////////////////////////////////////////////////////////////////
    //method for determining if the MAC address is valid or not using pattern ReGex and Matcher class
public static String  isValidMACAddress(String MACaddress){
 
        // Regex to check valid
        // MAC address
        String regex = "^([0-9A-Fa-f]{2}[:-])"
                       + "{5}([0-9A-Fa-f]{2})|"
                       + "([0-9a-fA-F]{4}\\."
                       + "[0-9a-fA-F]{4}\\."
                       + "[0-9a-fA-F]{4})$"; 
 
        // Compile the ReGex
        Pattern p = Pattern.compile(regex);
 
        // If the string is empty display the sentence below
        if (MACaddress == null)
        {
            return "You did not enter an Address, please try again.";
        }
 
        // Find match between given string and regular expression uSing Pattern.matcher()
 
        Matcher m = p.matcher(MACaddress);
 
        // Return if the string
        // matched the ReGex
        return "The entered string is a " + m.matches() + " MAC address";
    }
    
    }
    
    

